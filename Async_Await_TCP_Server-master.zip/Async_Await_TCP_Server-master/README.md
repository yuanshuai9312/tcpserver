# Async_Await_TCP_Server
async await tcp server!
TCP Server using Async and Await,can accept more than 10000 connections!

![image](https://github.com/OwnDing/Async_Await_TCP_Server/blob/master/pictures/tcp12000.PNG)

